﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
namespace IFN563_Final_FengshiDiao_n10840044
{
    public interface Player
    {
        string Name { set; get; }
        List<Piece> Piece_Player { get; set; }
        string GiveMove(Game game);
    }
    public class Human_Player: Player 
    {
        public string Name { set; get; }
        public List<Piece> Piece_Player { get; set; }
        public string GiveMove(Game game)
        {
            WriteLine("* Enter 'H' for help");
            Write($"{Name}, please give a move >> ");
            string enter = Convert.ToString(ReadLine());
            return enter;
        }
    }
    public class Robot_Player : Player 
    {
        public string Name { set; get; }
        public List<Piece> Piece_Player { get; set; }
        public string GiveMove(Game game)
        {
            Random randomSelect = new Random();
            bool outString = false;
            int miniRow = game.Board.Pieces_OnBoard.Last().Row_Site - 2;
            int maxRow = game.Board.Pieces_OnBoard.Last().Row_Site + 2;
            int miniColumn = game.Board.Pieces_OnBoard.Last().Column_Site - 2;
            int maxColumn = game.Board.Pieces_OnBoard.Last().Column_Site + 2;
            while (!outString)
            {
                Piece_Player[0].Row_Site = randomSelect.Next(miniRow, maxRow);
                Piece_Player[0].Column_Site = randomSelect.Next(miniColumn, maxColumn);
                if (Piece_Player[0].Row_Site > 0 && Piece_Player[0].Row_Site <= game.Board.Row && Piece_Player[0].Column_Site > 0 && Piece_Player[0].Column_Site <= game.Board.Column) // check if it is valid about Row_Site and Column_Site
                {
                    if (!game.Board.IsOnBoard(Piece_Player[0].Row_Site, Piece_Player[0].Column_Site))
                    {
                        outString = true;
                    }
                }
            }
            string value = $"{Piece_Player[0].Row_Site} {Piece_Player[0].Column_Site}";
            return value;
        }
    }
}
