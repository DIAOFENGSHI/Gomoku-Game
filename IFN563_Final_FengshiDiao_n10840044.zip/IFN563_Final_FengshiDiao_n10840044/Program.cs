﻿using System;
using static System.Console;

namespace IFN563_Final_FengshiDiao_n10840044
{
    class Program
    {
        static void Main(string[] args)
        {
            bool success = false;
            while (!success)
            {
                Clear(); // refresh screen
                string enter;
                enter = "Connect_Game"; //Default
                AbstractFactory game_Factory = FactoryProducer.getFactory(enter);
                WriteLine(">>>Welcome to Connect Game<<<"); //Menu
                WriteLine();
                string[] MainMenu = new string[] { "-----Gomoku_Connect", "-----Four_Connect", "-----QUIT" }; //Option
                foreach (string option in MainMenu)
                {
                    WriteLine("Option " + option);
                }
                WriteLine();
                while (!success) // until quit
                {
                    Write("Please enter the name of option (case sensitive) >> ");
                    enter = Convert.ToString(ReadLine());
                    if (enter == "Gomoku_Connect")
                        break;
                    else if (enter == "Four_Connect")
                        break;
                    else if (enter == "QUIT")
                    {
                        success = true;
                        break;
                    }
                }
                if(!success) // until quit
                {
                    Clear();
                    Game game = game_Factory.GetGame(enter);
                    game.ShowMenu();
                }
            }
        }
    }
}
