﻿namespace IFN563_Final_FengshiDiao_n10840044
{
    public class FactoryProducer //create abstract factories
    {
        public static AbstractFactory getFactory(string choice)
        {
            switch (choice)
            {
                case "Connect_Game": 
                    return new ConnectGame_Factory(); //create a new connect factory
                default:
                    return null;
            }
        }
    }
}
