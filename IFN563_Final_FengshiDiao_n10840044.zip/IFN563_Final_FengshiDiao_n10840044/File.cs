﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
using System.IO;
namespace IFN563_Final_FengshiDiao_n10840044
{
    public class File
    {
        private string path;
        public File(Game game)
        {
            string dirName = GetDirectory_GameHistory();
            DateTime datatime = DateTime.Now;
            string datatime_String = datatime.ToString("s"+ "-" +"m" + "-" + "H" + "-" + "dd" + "-" + "MM" + "-" + "yyy");
            string fileName = game.Name + @"-" + datatime_String + @".txt";
            path = dirName + @"\" + fileName;
        }

        public static string GetDirectory_GameHistory()
        {
            string currentFolder_Path = Directory.GetCurrentDirectory();
            string GameHistoryFolder_Directory = null; 
            for (int i = 0; i < 2; i++)
            {
                GameHistoryFolder_Directory = Path.GetDirectoryName(currentFolder_Path);
                currentFolder_Path = GameHistoryFolder_Directory;
            }
            GameHistoryFolder_Directory += @"\GameHistory";
            return GameHistoryFolder_Directory;
        }
        public static void Fill_GameHistory(Game game)
        {
            game.History = new List<string>();
            string directory = GetDirectory_GameHistory();
            string[] files;
            files = Directory.GetFiles(directory);
            foreach (string file in files)
            {
                if (file.Contains("n10840044") && file.Contains(game.Name))
                {
                    game.History.Add(file);
                }
            }
        }
        public static bool Get_HistoryInfo(Game game)
        {
            string value = null;
            string[] NameField;
            string formatName = null;
            List<string> fileNames = new List<string>();
            char DELIM = '\\';
            while (value != "Q")
            {
                WriteLine(">>>     GAME HISTORY     <<<");
                if (game.History.Count() == 0)
                {
                    WriteLine("Empty now!");
                    Write("Enter Q to back>> ");
                    value = Convert.ToString(ReadLine());
                }
                else
                {
                    for (int i = 0; i < game.History.Count; i++)
                    {
                        NameField = game.History[i].Split(DELIM);
                        string fileName = null;
                        fileNames.Add(fileName);
                        fileNames[i] = NameField.Last();
                        formatName = "#Item" + "  " + fileNames[i];
                        WriteLine(formatName);
                    }
                    WriteLine("QUIT");
                    int leftDistance_Cursor = formatName.Length;
                    int topDistance_Cursor = 1;
                    int optionNum_Mnue = fileNames.Count + 1;
                    int enter = game.GetMenuCommand(leftDistance_Cursor, topDistance_Cursor, optionNum_Mnue);
                    int index = enter - 1;
                    if(enter == optionNum_Mnue)
                        value = "Q";
                    else
                    {
                        ReadGame(game, game.History[index]);
                        return true;
                    }   
                }
                Clear();
                
            }
            return false;
        }
        public static void WriteGame(Game game)
        {
            const char DELIM = ',';
            File file = new File(game);
            WriteLine(file.path);
            FileStream outFile = new FileStream(file.path, FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(outFile);
            writer.WriteLine(game.Mode);
            for (int i = 0; i < game.Board.Pieces_OnBoard.Count; i++)
            {
                string row = Convert.ToString(game.Board.Pieces_OnBoard[i].Row_Site);
                string column = Convert.ToString(game.Board.Pieces_OnBoard[i].Column_Site);
                writer.WriteLine(row + DELIM + column + DELIM + game.Board.Pieces_OnBoard[i].Shape_Site);
            }
            writer.Close();
            outFile.Close();
            WriteLine("The game already saved successfully!");
        }
        public static void ReadGame(Game game, string filePath)
        {
            const char DELIM = ',';
            AbstractFactory game_Factory = FactoryProducer.getFactory(game.Type);
            FileStream inFile = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(inFile);
            string pieceIn;
            string[] fields;
            game.Mode = reader.ReadLine();
            game.Buid_Mode(game.Mode);
            pieceIn = reader.ReadLine();
            for (int i = 0; pieceIn != null; i++)
            {
                fields = pieceIn.Split(DELIM);
                Piece piece = game_Factory.GetPiece(fields[2]);
                game.Board.Pieces_OnBoard.Add(piece);
                game.Board.Pieces_OnBoard[i].Row_Site = Convert.ToInt32(fields[0]);
                game.Board.Pieces_OnBoard[i].Column_Site = Convert.ToInt32(fields[1]);
                pieceIn = reader.ReadLine();
            }
            reader.Close();
            inFile.Close();
            WriteLine("The game was read successfully!");
        }
    }
}
