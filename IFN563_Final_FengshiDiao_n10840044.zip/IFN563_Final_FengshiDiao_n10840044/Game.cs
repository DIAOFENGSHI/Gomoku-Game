﻿using System;
using System.Collections.Generic;
using System.Linq;
using static System.Console;
namespace IFN563_Final_FengshiDiao_n10840044
{
    public interface Game
    {
        string Type { get; }
        string Name { get; }
        string Mode { get; set; }
        bool Over { get; set; }
        Board Board { get; set; }
        Help Help { get; set; }
        Piece HoldPiece { get; set; }
        List<string> History { get; set; }
        MoveController MoveController { get; set; }
        int GetMenuCommand(int left, int top, int optionNum);
        void ShowMenu();
        void PlayGame(AbstractFactory game_Factory);
        void Buid_Mode(string mode);
    }
    public abstract class Connect_Game : Game
    {
        public MoveController MoveController { get; set; }
        public bool Over { get; set; }
        public Help Help { get; set; }
        public Player[] players = new Player[2];
        public Piece HoldPiece { get; set; }
        public Board Board { get; set; }
        public List<string> History { get; set; }
        public string Type { get => "Connect_Game"; }
        public abstract string Name { get; }
        public string Mode { get; set; }
        public void ShowMenu() // display the homepage of connect game
        {
            string[] MenuOptions = new string[]
                {
                " >>>          PLAYER          <<< ",
                " >>>          COMPUTER        <<< ",
                " >>>          HISTORY         <<< ",
                " >>>          HELP            <<< ",
                " >>>          QUIT            <<< "
                }; // the options of menu
            int leftDistance_Cursor = MenuOptions[0].Length - 1;
            int topDistance_Cursor = 1;
            int optionNum_Mnue = MenuOptions.Length;
            string mode;
            AbstractFactory game_Factory = FactoryProducer.getFactory(Type); //create game by its type
            do
            {
                Over = false;
                WriteLine($" ---  Welcome to {this.Name}  ---");
                foreach (string option in MenuOptions)
                {
                    WriteLine(option);
                }
                WriteLine("*Press Enter to check");
                WriteLine("*Press UpArrow  and DonwArrow to move");
                int enter = GetMenuCommand(leftDistance_Cursor, topDistance_Cursor, optionNum_Mnue); //get selection
                Clear();
                switch (enter) //execute method by the selection
                {
                    case 1:
                        mode = "Player";
                        Buid_Mode(mode); //load human vs human mode
                        PlayGame(game_Factory); 
                        break;
                    case 2:
                        mode = "Computer";
                        Buid_Mode(mode); //load human vs robot mode 
                        PlayGame(game_Factory);
                        break;
                    case 3:
                        if (File.Get_HistoryInfo(this)) //browse game history
                            Clear();
                            PlayGame(game_Factory); //playing if load saved game
                        break;
                    case 4:
                        Help.Get_GeneralHelp(); //call general help
                        break;
                    case 5:
                        Over = true; //quit the homepage
                        break;
                }
            } while (!Over);
        }
        public void PlayGame(AbstractFactory game_Factory) // Gomoku and Four_connect games
        {
            int index_Player = 0; 
            if(Board.Pieces_OnBoard.Count % 2 == 1) // get that who is first player by the number of pieces on board
            {
                index_Player = 1;
            }
            Board.Draw(); // refresh board
            while(!Over) // until game over
            {
                while (index_Player < players.Count() && !Over) // until game over and finished one turn
                {
                    if (game_Factory.GetMove(players[index_Player], this)) //get player move, PlayPiece and Quit return 'true', other operations return 'false'
                    {
                        if (Board.Pieces_OnBoard.Count >= 9 && Board.GetWinner())  //open the check of winner when pieces on board is over 9
                        {
                            WriteLine($"{players[index_Player].Name} won!"); //display the winner
                            Over = true;
                            ReadKey(); //enter any key to quit
                            break;
                        }
                        index_Player++;
                    }
                }
                index_Player = 0;
            }  
        }
        public void Buid_Mode(string mode) //load game mode
        {
            switch (mode)
            {
                case "Computer": // human vs robot
                    Mode = mode;
                    AbstractFactory game_Factory = FactoryProducer.getFactory(Type);
                    players = game_Factory.GetPlayers(this);
                    players[0].Piece_Player = new List<Piece>();
                    players[1].Piece_Player = new List<Piece>();
                    players[0].Piece_Player.Add(game_Factory.GetPiece("\u25cb"));
                    players[1].Piece_Player.Add(game_Factory.GetPiece("\u25b2"));
                    break;
                case "Player": // human vs huamn
                    Mode = mode;
                    AbstractFactory game_Factory_two = FactoryProducer.getFactory(Type);
                    players = game_Factory_two.GetPlayers(this);
                    players[0].Piece_Player = new List<Piece>();
                    players[1].Piece_Player = new List<Piece>();
                    players[0].Piece_Player.Add(game_Factory_two.GetPiece("\u25cb"));
                    players[1].Piece_Player.Add(game_Factory_two.GetPiece("\u25b2"));
                    break;
            }  
        }
        public int GetMenuCommand(int left, int top, int optionNum)// control the cursor
        {
            SetCursorPosition(left, top); //set the cursor position
            int initialTop = top;
            bool pass = true;
            do
            {
                ConsoleKeyInfo info = ReadKey();
                switch (info.Key)
                {
                    case ConsoleKey.Enter:
                        pass = false;
                        break;
                    case ConsoleKey.UpArrow:
                        if (top > initialTop && top <= initialTop + optionNum - 1)
                        {
                            top -= 1;
                            SetCursorPosition(left, top);
                        }
                        else
                        {
                            SetCursorPosition(left, top);
                        }
                        break;
                    case ConsoleKey.DownArrow:
                        if (top >= initialTop && top < initialTop + optionNum - 1)
                        {
                            top += 1;
                            SetCursorPosition(left, top);
                        }
                        else
                        {
                            SetCursorPosition(left, top);
                        }
                        break;
                    default:
                        Console.SetCursorPosition(left, top);
                        break;
                }

            } while (pass);
            SetCursorPosition(0, optionNum + 1);
            return top + 1 - initialTop; //return the order number of option
        } 
    }
    public class Gomoku_Connect: Connect_Game
    {
        public override string Name { get => "Gomoku_Connect"; }
        public Gomoku_Connect()
        {
            AbstractFactory game_Factory = FactoryProducer.getFactory(Type);
            Help = game_Factory.GetHelp();
            Board = game_Factory.GetBoard();
            Board.Row = 15;
            Board.Column = 15;
            Board.WinPiece_Num = 5;
            MoveController = new MoveController();
            File.Fill_GameHistory(this);
        }
    }
    public class Four_Connect : Connect_Game
    {
        public override string Name { get => "Four_Connect"; }
        public Four_Connect()
        {
            AbstractFactory game_Factory = FactoryProducer.getFactory(Type);
            Help = game_Factory.GetHelp();
            Board = game_Factory.GetBoard();
            Board.Row = 7;
            Board.Column = 6;
            Board.WinPiece_Num = 4;
            MoveController = new MoveController();
            File.Fill_GameHistory(this);
        }
    }
}
