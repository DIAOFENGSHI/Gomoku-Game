﻿using System.Collections.Generic;
namespace IFN563_Final_FengshiDiao_n10840044
{
    public class MoveController
    {
        private List<Move> moves;
        public MoveController()
        {
            moves = new List<Move>();
        }
        public void CreateMove(Move move, Game game)
        {
            move.Execute(game); //execute te moves by actual object of move
            moves.Add(move);
        }
    }
}
