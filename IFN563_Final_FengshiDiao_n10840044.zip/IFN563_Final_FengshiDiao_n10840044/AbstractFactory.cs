﻿using System;
using static System.Console;

namespace IFN563_Final_FengshiDiao_n10840044
{
    public abstract class AbstractFactory 
    {
        public abstract Game GetGame(string gameName);
        public abstract bool GetMove(Player player, Game game);
        public abstract Player[] GetPlayers(Game game);
        public abstract Piece GetPiece(string pieceShape);
        public abstract Board GetBoard();
        public abstract Help GetHelp();
    }

    class ConnectGame_Factory : AbstractFactory
    {
        public override Game GetGame(string gameName)
        {
            switch (gameName)
            {
                case "Gomoku_Connect":
                    return new Gomoku_Connect();
                case "Four_Connect":
                    return new Four_Connect();
                default:
                    return null;
            }
        }
        public override bool GetMove(Player player, Game game)
        {
            string moveName = player.GiveMove(game);
            switch (moveName)
            {
                case "U": //Undo
                    int min_Undo_Allow = 2;
                    if (game.Board.Pieces_OnBoard.Count >= min_Undo_Allow)
                    {
                        game.MoveController.CreateMove(new UndoMove(), game);
                        Clear();
                        game.Board.Draw();
                    }
                    else
                        WriteLine("The current status can not support Undo!");
                    return false;

                case "R": //Redo
                    int min_Redo_Allow = 2;
                    if (game.Board.Pieces_OnBoard_Redo.Count >= min_Redo_Allow)
                    {
                        game.MoveController.CreateMove(new RedoMove(), game);
                        Clear();
                        game.Board.Draw();
                    }   
                    else
                        WriteLine("The current status can not support Redo!");
                    return false;

                case "Q": //Quit
                    game.Over = true;
                    return true;

                case "S": //Save
                    game.MoveController.CreateMove(new SaveGame(), game);
                    return false;

                case "H": //Help
                    Clear();
                    game.MoveController.CreateMove(new GameHelp(), game);
                    Clear();
                    game.Board.Draw();
                    return false;

                default:
                    try //using try-catch for exceptions
                    {
                        string[] values = moveName.Split(new char[] { ' ' }, 2, StringSplitOptions.RemoveEmptyEntries); // to set a "Space" as delimit , array size and without empty array elements by string.Split  //check the delimit of input by using char type delimit 
                        int row_Site = Convert.ToInt32(values[0]);
                        int column_Site = Convert.ToInt32(values[1]);
                        string shape = player.Piece_Player[0].Shape_Site;
                        if (row_Site > 0 && row_Site <= game.Board.Row && column_Site > 0 && column_Site <= game.Board.Column) // check if it is valid about Row_Site and Column_Site
                        {
                            if (game.Board.IsOnBoard(row_Site, column_Site))
                            {
                                WriteLine("it already existed in the board, enter it again !");
                            }
                            else
                            {
                                AbstractFactory abstractFactory = FactoryProducer.getFactory(game.Type);
                                game.HoldPiece = abstractFactory.GetPiece(player.Piece_Player[0].Shape_Site);
                                game.HoldPiece.Column_Site = column_Site;
                                game.HoldPiece.Row_Site = row_Site;
                                game.MoveController.CreateMove(new PlayPiece(), game);
                                Clear();
                                game.Board.Draw();
                                return true;
                            }
                        }
                        else //to prevent out of range
                            WriteLine("out of the range, enter it again !");
                    }
                    catch //to prevent any exceptions
                    {
                        WriteLine("wrong input format, enter it again !");
                    }
                    return false;
            }
        }
        public override Player[] GetPlayers(Game game)
        {
            switch (game.Mode)
            {
                case "Computer":
                    Human_Player human = new Human_Player();
                    human.Name = "Player 1";
                    Robot_Player robot = new Robot_Player();
                    robot.Name = "Player 2";
                    return new Player[] {human, robot};
                case "Player":
                    Human_Player human_one = new Human_Player();
                    human_one.Name = "Player 1";
                    Human_Player human_two  = new Human_Player();
                    human_two.Name = "Player 2";
                    return new Player[] { human_one, human_two};
                default:
                    return null;
            }
        }
        public override Piece GetPiece(string pieceShape)
        {
            switch (pieceShape)
            {
                case "\u25cb":
                    return new Circle_Piece();
                case "\u25b2":
                    return new Triangle_Piece();
                default:
                    return null;
            }
        }
        public override Board GetBoard()
        {
            return new Connect_Board();
        }
        public override Help GetHelp()
        {
            return new Connect_Help();
        }
    }
}
