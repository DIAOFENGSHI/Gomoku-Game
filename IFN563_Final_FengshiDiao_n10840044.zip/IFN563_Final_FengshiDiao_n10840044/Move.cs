﻿namespace IFN563_Final_FengshiDiao_n10840044
{
    public interface Move
    {
        void Execute(Game game);
    }
    public class PlayPiece : Move
    {
        public void Execute(Game game)
        {
            game.Board.AddPiece(game);
        }
    }
    public class SaveGame : Move
    {
        public void Execute(Game game)
        {
            File.WriteGame(game);
        }
    }
    public class GameHelp : Move
    {
        public void Execute(Game game)
        {
            game.Help.Get_SpecificHelp();
        }
    }
    public class UndoMove: Move
    {
        public void Execute(Game game)
        {
            game.Board.UndoPiece();
        }
    }
    public class RedoMove : Move
    {
        public void Execute(Game game)
        {
            game.Board.RedoPiece();
        }
    }
}
