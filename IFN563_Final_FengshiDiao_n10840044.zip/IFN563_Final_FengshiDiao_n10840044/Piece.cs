﻿namespace IFN563_Final_FengshiDiao_n10840044
{
    public interface Piece
    {
        int Column_Site { get; set; }
        int Row_Site { get; set; }
        string Shape_Site { get; set; }
    }
    public class Circle_Piece: Piece 
    {
        public int Column_Site { get; set; }
        public int Row_Site { get; set; }
        public string Shape_Site { get { return "\u25cb"; } set { } }
    }
    public class Triangle_Piece: Piece 
    {
        public int Column_Site { get; set; }
        public int Row_Site { get; set; }
        public string Shape_Site { get { return "\u25b2"; } set { } }
    }
}
