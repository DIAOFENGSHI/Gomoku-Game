﻿using System;
using static System.Console;
namespace IFN563_Final_FengshiDiao_n10840044
{
    public interface Help
    {
        string GeneralRule { get; }
        string SpecificRule { get; }
        void Get_GeneralHelp();
        void Get_SpecificHelp();
    }
    public class Connect_Help: Help
    {
        public string GeneralRule 
        {
            get 
            {
                string General =
                    "--- Rule ---\n"+
                    "* This is a classic game that you will enjoy playing with your friends and family\n" +
                    "* To win Connect Four you have to be the first player to get the win number of your colored checkers in a line either horizontally, vertically or diagonally\n" +
                    "* Win number is five in the Gomoku and is four in the Connect-Four\n"+
                    "--- Piece Shape ---\n" +
                    "* In player mode, player one using triangle shape of piece and player using circle shape of piece\n" +
                    "* In computer mode, robot player using triangle shape of piece and human player using circle shape of piece \n" +
                    "--- Instruction ---\n" +
                    "* Enter 'U' to undo previous piece\n" +
                    "* Enter 'R' to redo previous piece\n" +
                    "* Enter 'Q' to quit the current game\n" +
                    "* Enter 'S' to save the current game\n" +
                    "* Enter 'S' to save the current game\n" +
                    "* Enter the number of row and the number of column to play piece\n" +
                    "* Ex. 5 8 means row 5 column 8\n" +
                    "* Notice: row and column is delimited by a space\n" +
                    "* Notice: Letters is case sensitive\n";
                return General;
            } 
        }
        public string SpecificRule
        {
            get
            {
                string Specific =
                    "--- Piece Shape ---\n" +
                    "* In player mode, player one using triangle shape of piece and player using circle shape of piece\n" +
                    "* In computer mode, robot player using triangle shape of piece and human player using circle shape of piece \n" +
                    "--- Instruction ---\n" +
                    "* Enter 'U' to undo previous piece\n" +
                    "* Enter 'R' to redo previous piece\n" +
                    "* Enter 'Q' to quit the current game\n" +
                    "* Enter 'S' to save the current game\n" +
                    "* Enter 'S' to save the current game\n" +
                    "* Enter the number of row and the number of column to play piece\n" +
                    "* Noticea: row and column is delimited by a space\n"+
                    "* Notice: Letters is case sensitive\n";
                return Specific;
            }
        }
        public void Get_GeneralHelp()
        {
            bool over = false;
            WriteLine("General Help Document");
            WriteLine(GeneralRule);
            Write("Please enter 'Q' to quit the Help >> ");
            do
            {
                string quite = Convert.ToString(ReadLine());
                if (quite == "Q")
                {
                    Clear();
                    over = true;
                }
                else
                    Write("It is invalid please enter 'Q' to quit >> ");
            } while (!over);
        }
        public void Get_SpecificHelp() 
        {
            bool over = false;
            WriteLine("Specific Help Document");
            WriteLine(SpecificRule);
            Write("Please enter 'Q' to quit the Help >> ");
            do
            {
                string quite = Convert.ToString(ReadLine());
                if (quite == "Q")
                {
                    over = true;
                }
                else
                    Write("It is invalid please enter 'Q' to quit >> ");
            } while (!over);
        }
    }
}
