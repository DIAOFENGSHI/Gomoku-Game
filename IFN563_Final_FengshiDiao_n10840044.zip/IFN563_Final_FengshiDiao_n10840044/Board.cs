﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;
namespace IFN563_Final_FengshiDiao_n10840044
{
    public interface Board
    {
        int WinPiece_Num { get; set; }
        int Row { get; set; }
        int Column { get; set; }
        List<Piece> Pieces_OnBoard { get; set; }
        List<Piece> Pieces_OnBoard_Redo { get; set; }
        void Draw();
        bool IsOnBoard(int row_Site, int column_Site);
        bool GetWinner();
        void UndoPiece();
        void RedoPiece();
        void AddPiece(Game game);
        
    }
    public class Connect_Board : Board
    {
        public int WinPiece_Num { get; set; }
        public int Row { get; set; }
        public int Column { get; set; }
        public List<Piece> Pieces_OnBoard { get; set; }
        public List<Piece> Pieces_OnBoard_Redo { get; set; }
        public Connect_Board()
        {
            Pieces_OnBoard = new List<Piece>();
            Pieces_OnBoard_Redo = new List<Piece>();
        }
        public void AddPiece(Game game)
        {
            Pieces_OnBoard.Add(game.HoldPiece);
        }
        public void Draw() 
        {
            OutputEncoding = Encoding.UTF8; // all from the Font Arial
            string straightLine = "\u2500\u2500\u2500"; // Box Drawings Light Vertical │
            string tUpLine = "\u252C";
            string tDownLine = "\u2534";
            string upLeftCorner = "\u250C";
            string upRightCorner = "\u2510";
            string downLeftCorner = "\u2514";
            string downRightCorner = "\u2518";
            string verticalLine = "\u2502";
            string upLine = null;
            string downLine = null;
            string middleLine = null;
            string PieceLine = null;
            int middleLineNum = Row - 1;
            // initialize virtual pieces on board as empty
            string[,] VirtualPieces = new string[Row, Column];
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Column; j++)
                {
                    VirtualPieces[i, j] = null;
                }
            }
            // pass shape of sits from this.board.pieces to this.board.draw
            for (int i = 0; i < Pieces_OnBoard.Count; i++)
            {
                VirtualPieces[Pieces_OnBoard[i].Row_Site - 1, Pieces_OnBoard[i].Column_Site - 1] = Pieces_OnBoard[i].Shape_Site + " ";
            }

            WriteLine("                  >>Current board below<<                   ");
            // start to draw the whole board and Piecees
            // upper boundary
            for (int x = 0; x < (Column - 1); x++)
            {
                upLine += straightLine + tUpLine;
            }
            upLine = upLeftCorner + upLine + straightLine + upRightCorner;
            WriteLine(upLine);
            //Piecees around Line and Middle Boundary
            for (int i = 0; i < Row; i++)
            {
                //Piecees around Line
                for (int j = 0; j < Column; j++)
                {
                    string test = null;
                    if (VirtualPieces[i, j] == test)
                    {
                        PieceLine += verticalLine + " " + "  ";
                    }
                    else
                    {
                        PieceLine += verticalLine + " " + VirtualPieces[i, j];
                    }
                }
                PieceLine = PieceLine + verticalLine;
                WriteLine(PieceLine);
                PieceLine = null;
                // Middle Boundary
                for (int x = 0; x < Column; x++)
                {
                    middleLine += verticalLine + straightLine;
                }
                middleLine = middleLine + verticalLine;
                if (middleLineNum != i)
                {
                    WriteLine(middleLine);
                    middleLine = null;
                }
            }
            // Lower Boundary
            for (int x = 0; x < (Column - 1); x++)
            {
                downLine += straightLine + tDownLine;
            }
            downLine = downLeftCorner + downLine + straightLine + downRightCorner;
            WriteLine(downLine);
        }
        public bool IsOnBoard(int row_Site, int column_Site)
        {
            bool itis = false;
            for (int i = 0; i < Pieces_OnBoard.Count; i++)
            {
                if (Pieces_OnBoard[i].Row_Site == row_Site && Pieces_OnBoard[i].Column_Site == column_Site)
                {
                    itis = true;
                    break;
                }
            }
            return itis;
        }
        public bool GetWinner()
        {
            bool win = false;
            int count = 0;
            int virtualRow = Pieces_OnBoard.Last().Row_Site;
            int virtualColumn = Pieces_OnBoard.Last().Column_Site;
            string virtualShape = Pieces_OnBoard.Last().Shape_Site;

            for (int i = 0; i < WinPiece_Num; i++)
            {
                foreach (Piece p in Pieces_OnBoard)
                {
                    if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                    {
                        count++;
                        virtualRow++;
                        break;
                    }
                }
            }
            if (count < WinPiece_Num)
            {
                virtualRow = virtualRow - count - 1;
                for (int i = 0; i < WinPiece_Num; i++)
                {
                    foreach (Piece p in Pieces_OnBoard)
                    {
                        if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                        {
                            count++;
                            virtualRow--;
                            break;
                        }
                    }
                }
            }
            if (count < WinPiece_Num)
            {
                count = 0;
                virtualRow = Pieces_OnBoard.Last().Row_Site;
                for (int i = 0; i < WinPiece_Num; i++)
                {
                    foreach (Piece p in Pieces_OnBoard)
                    {
                        if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                        {
                            count++;
                            virtualColumn++;
                            break;
                        }
                    }
                }
                if (count < WinPiece_Num)
                {
                    virtualColumn = virtualColumn - count - 1;
                    for (int i = 0; i < WinPiece_Num; i++)
                    {
                        foreach (Piece p in Pieces_OnBoard)
                        {
                            if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                            {
                                count++;
                                virtualColumn--;
                                break;
                            }
                        }
                    }
                }
            }
            if (count < WinPiece_Num)
            {
                count = 0;
                virtualColumn = Pieces_OnBoard.Last().Column_Site;
                for (int i = 0; i < WinPiece_Num; i++)
                {
                    foreach (Piece p in Pieces_OnBoard)
                    {
                        if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                        {
                            count++;
                            virtualColumn++;
                            virtualRow++;
                            break;
                        }
                    }
                }
                if (count < WinPiece_Num)
                {
                    virtualColumn = virtualColumn - count - 1;
                    virtualRow = virtualRow - count - 1;
                    for (int i = 0; i < WinPiece_Num; i++)
                    {
                        foreach (Piece p in Pieces_OnBoard)
                        {
                            if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                            {
                                count++;
                                virtualColumn--;
                                virtualRow--;
                                break;
                            }
                        }
                    }
                }
            }
            if (count < WinPiece_Num)
            {
                count = 0;
                virtualColumn = Pieces_OnBoard.Last().Column_Site;
                virtualRow = Pieces_OnBoard.Last().Row_Site;
                for (int i = 0; i < WinPiece_Num; i++)
                {
                    foreach (Piece p in Pieces_OnBoard)
                    {
                        if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                        {
                            count++;
                            virtualColumn++;
                            virtualRow--;
                            break;
                        }
                    }
                }
                if (count < WinPiece_Num)
                {
                    virtualColumn = virtualColumn - count - 1;
                    virtualRow = virtualRow + count + 1;
                    for (int i = 0; i < WinPiece_Num; i++)
                    {
                        foreach (Piece p in Pieces_OnBoard)
                        {
                            if (p.Row_Site == virtualRow && p.Column_Site == virtualColumn && p.Shape_Site == virtualShape)
                            {
                                count++;
                                virtualColumn--;
                                virtualRow++;
                                break;
                            }
                        }
                    }
                }
            }
            if (count >= WinPiece_Num)
                win = true;
            return win;
        }
        public void UndoPiece()
        {
            int miniNum_Piece = 2;
            
            for(int i = 0; i < miniNum_Piece;i++)
            {
                int index = Pieces_OnBoard.Count - 1;
                Pieces_OnBoard_Redo.Add(Pieces_OnBoard.Last());
                Pieces_OnBoard.RemoveAt(index);
            }
        }
        public void RedoPiece()
        {
            int miniNum_Piece = 2;
            for (int i = 0; i < miniNum_Piece; i++)
            {
                int index_Undo = Pieces_OnBoard_Redo.Count - 1;
                Pieces_OnBoard.Add(Pieces_OnBoard_Redo.Last());
                Pieces_OnBoard_Redo.RemoveAt(index_Undo); 
            }
        }
    }
}
